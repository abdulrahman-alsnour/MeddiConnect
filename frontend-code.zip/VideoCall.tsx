/**
 * Video Call Component
 * 
 * Simple WebRTC-based video call interface for doctor-patient appointments.
 * 
 * Features:
 * - Peer-to-peer video and audio communication
 * - Camera and microphone controls
 * - Clean, simple UI
 * 
 * How it works:
 * - Doctor starts the call (initiator)
 * - Patient joins via shared link/code
 * - Uses WebRTC for direct peer-to-peer connection
 * - No external video calling service required
 */

import React, { useEffect, useRef, useState } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import {
  Box,
  Paper,
  Typography,
  Button,
  IconButton,
  CircularProgress,
  Alert,
  Card,
  CardContent,
} from '@mui/material';
import {
  Videocam,
  VideocamOff,
  Mic,
  MicOff,
  CallEnd,
  Person,
} from '@mui/icons-material';
import { useAuth } from '../context/AuthContext';
import DoctorLayout from '../components/DoctorLayout';
import PatientLayout from '../components/PatientLayout';
import { useWebSocketVideo } from '../hooks/useWebSocketVideo';

// Video call configuration
const ICE_SERVERS = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
  ],
};

interface VideoCallProps {
  appointmentId: string;
  doctorId: number;
  patientId: number;
  isDoctor: boolean;
  patientName?: string;
  doctorName?: string;
}

const VideoCall: React.FC = () => {
  const { appointmentId } = useParams<{ appointmentId: string }>();
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuth();

  // Check if opened in popup window
  const isPopup = window.opener !== null;

  // Extract props from location state, sessionStorage (for popup), or params
  let state = location.state as VideoCallProps | null;
  
  // If opened in popup and no state, try to get from sessionStorage
  if (isPopup && !state && appointmentId) {
    try {
      const storedData = sessionStorage.getItem(`videoCall_${appointmentId}`);
      if (storedData) {
        const parsed = JSON.parse(storedData);
        state = {
          appointmentId: parsed.appointmentId,
          doctorId: parsed.doctorId,
          patientId: parsed.patientId,
          isDoctor: parsed.isDoctor,
          patientName: parsed.patientName,
          doctorName: parsed.doctorName,
        };
        // Use token from sessionStorage if available
        if (parsed.token && !user?.token) {
          // Token is stored but we need to handle auth differently
          // For now, we'll rely on the user context
        }
      }
    } catch (e) {
      console.error('Error reading from sessionStorage:', e);
    }
  }

  const doctorId = state?.doctorId || 0;
  const patientId = state?.patientId || 0;
  const isDoctor = state?.isDoctor || false;
  const patientName = state?.patientName || 'Patient';
  const doctorName = state?.doctorName || 'Doctor';

  // Debug logging
  console.log('VideoCall component mounted:', {
    appointmentId,
    state,
    doctorId,
    patientId,
    isDoctor,
    isPopup,
    user: user ? 'authenticated' : 'not authenticated',
  });

  // WebRTC refs
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);
  const peerConnectionRef = useRef<RTCPeerConnection | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);

  // State management
  const [isConnected, setIsConnected] = useState(false);
  const [isVideoEnabled, setIsVideoEnabled] = useState(true);
  const [isAudioEnabled, setIsAudioEnabled] = useState(true);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [callDuration, setCallDuration] = useState(0);
  const [wsConnected, setWsConnected] = useState(false);
  
  // Store interval ID for cleanup
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const isOfferSentRef = useRef(false);
  const isAnswerSentRef = useRef(false);

  // WebSocket connection for video signaling
  const { connected: wsConnectedState, sendSignal, disconnect: disconnectWS, stompError } = useWebSocketVideo({
    token: user?.token || null,
    appointmentId: appointmentId || null,
    onSignalReceived: (signal) => {
      handleIncomingSignal(signal);
    },
    onError: (err) => {
      console.error('WebSocket error:', err);
      // Don't show error immediately, let it retry
    },
    onConnected: () => {
      console.log('WebSocket connected for video call');
      setWsConnected(true);
    },
    onDisconnected: () => {
      console.log('WebSocket disconnected for video call');
      setWsConnected(false);
    },
  });

  /**
   * Handle incoming WebRTC signals (offer, answer, ICE candidates)
   */
  const handleIncomingSignal = async (signal: { type: string; sdp?: string; candidate?: RTCIceCandidateInit; sender?: string }) => {
    if (!peerConnectionRef.current) {
      console.warn('Peer connection not ready, ignoring signal');
      return;
    }

    // Ignore signals from ourselves
    if (signal.sender === user?.username) {
      console.log('Ignoring signal from self');
      return;
    }

    try {
      switch (signal.type) {
        case 'offer':
          // Patient receives offer from doctor
          if (!isDoctor && signal.sdp) {
            console.log('Received offer, creating answer...');
            await peerConnectionRef.current.setRemoteDescription(new RTCSessionDescription({ type: 'offer', sdp: signal.sdp }));
            
            // Create and send answer
            if (!isAnswerSentRef.current) {
              const answer = await peerConnectionRef.current.createAnswer();
              await peerConnectionRef.current.setLocalDescription(answer);
              
              sendSignal({
                type: 'answer',
                sdp: answer.sdp || undefined,
                sender: user?.username,
              });
              
              isAnswerSentRef.current = true;
              console.log('Answer sent');
            }
          }
          break;

        case 'answer':
          // Doctor receives answer from patient
          if (isDoctor && signal.sdp) {
            console.log('Received answer');
            await peerConnectionRef.current.setRemoteDescription(new RTCSessionDescription({ type: 'answer', sdp: signal.sdp }));
          }
          break;

        case 'ice-candidate':
          // Both receive ICE candidates
          if (signal.candidate) {
            console.log('Received ICE candidate');
            await peerConnectionRef.current.addIceCandidate(new RTCIceCandidate(signal.candidate));
          }
          break;

        default:
          console.warn('Unknown signal type:', signal.type);
      }
    } catch (err) {
      console.error('Error handling signal:', err);
      setError('Error processing connection signal. Please try again.');
    }
  };

  /**
   * Initialize user media (camera and microphone)
   * This gets access to the user's camera and microphone
   */
  const initializeMedia = async () => {
    try {
      // Request access to camera and microphone
      const stream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: true,
      });

      localStreamRef.current = stream;

      // Display local video
      if (localVideoRef.current) {
        localVideoRef.current.srcObject = stream;
      }

      setLoading(false);
      setIsConnected(true);
    } catch (err: any) {
      console.error('Error accessing media devices:', err);
      setError(
        err.name === 'NotAllowedError'
          ? 'Please allow camera and microphone access to start the call.'
          : 'Failed to access camera or microphone. Please check your device permissions.'
      );
      setLoading(false);
    }
  };

  /**
   * Create peer connection and set up WebRTC
   * This establishes the connection between doctor and patient
   */
  const createPeerConnection = () => {
    try {
      // Create RTCPeerConnection with ICE servers
      const peerConnection = new RTCPeerConnection(ICE_SERVERS);

      // Add local stream tracks to peer connection
      if (localStreamRef.current) {
        localStreamRef.current.getTracks().forEach((track) => {
          peerConnection.addTrack(track, localStreamRef.current!);
        });
      }

      // Handle incoming remote stream
      peerConnection.ontrack = (event) => {
        console.log('Received remote stream');
        if (remoteVideoRef.current && event.streams[0]) {
          remoteVideoRef.current.srcObject = event.streams[0];
          setIsConnected(true);
        }
      };

      // Handle ICE candidates - send them via WebSocket
      peerConnection.onicecandidate = (event) => {
        if (event.candidate && wsConnectedState) {
          console.log('Sending ICE candidate');
          sendSignal({
            type: 'ice-candidate',
            candidate: event.candidate.toJSON(),
            sender: user?.username,
          });
        }
      };

      // Handle connection state changes
      peerConnection.onconnectionstatechange = () => {
        const state = peerConnection.connectionState;
        console.log('WebRTC connection state:', state);

        if (state === 'connected') {
          setIsConnected(true);
        } else if (state === 'disconnected' || state === 'failed') {
          setIsConnected(false);
          if (state === 'failed') {
            setError('Connection lost. Please try again.');
          }
        }
      };

      peerConnectionRef.current = peerConnection;
    } catch (err) {
      console.error('Error creating peer connection:', err);
      setError('Failed to initialize video call connection.');
    }
  };

  /**
   * Start the video call
   * Doctor initiates, patient joins
   */
  const startCall = async () => {
    try {
      await initializeMedia();
      createPeerConnection();

      // Note: Offer will be sent automatically when WebSocket connects (see useEffect above)

      // Start call duration timer
      intervalRef.current = setInterval(() => {
        setCallDuration((prev) => prev + 1);
      }, 1000);
    } catch (err: any) {
      console.error('Error starting call:', err);
      setError(err.message || 'Failed to start call.');
      setLoading(false);
    }
  };

  /**
   * Toggle video (camera) on/off
   */
  const toggleVideo = () => {
    if (localStreamRef.current) {
      const videoTrack = localStreamRef.current.getVideoTracks()[0];
      if (videoTrack) {
        videoTrack.enabled = !isVideoEnabled;
        setIsVideoEnabled(!isVideoEnabled);
      }
    }
  };

  /**
   * Toggle audio (microphone) on/off
   */
  const toggleAudio = () => {
    if (localStreamRef.current) {
      const audioTrack = localStreamRef.current.getAudioTracks()[0];
      if (audioTrack) {
        audioTrack.enabled = !isAudioEnabled;
        setIsAudioEnabled(!isAudioEnabled);
      }
    }
  };

  /**
   * End the call and cleanup
   */
  const endCall = () => {
    // Clear interval timer
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }

    // Stop all tracks
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach((track) => {
        track.stop();
      });
      localStreamRef.current = null;
    }

    // Close peer connection
    if (peerConnectionRef.current) {
      peerConnectionRef.current.close();
      peerConnectionRef.current = null;
    }

    // Disconnect WebSocket
    disconnectWS();

    // Reset flags
    isOfferSentRef.current = false;
    isAnswerSentRef.current = false;
  };

  /**
   * Handle end call button click
   */
  const handleEndCall = async () => {
    // If doctor, call backend API to end the call
    if (isDoctor && appointmentId && user?.token) {
      try {
        await fetch(`http://localhost:8080/appointments/${appointmentId}/end-call`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${user.token}`,
            'Content-Type': 'application/json',
          },
        });
      } catch (err) {
        console.error('Error ending call:', err);
      }
    }

    endCall();

    // If opened in popup, close the popup window
    if (isPopup && window.opener) {
      window.close();
    } else {
      // Otherwise navigate back
      navigate(isDoctor ? '/doctor-online-appointments' : '/online-appointments');
    }
  };

  /**
   * Format call duration (MM:SS)
   */
  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Send offer when WebSocket connects (for doctor)
  useEffect(() => {
    if (isDoctor && wsConnectedState && peerConnectionRef.current && !isOfferSentRef.current && localStreamRef.current) {
      const sendOffer = async () => {
        try {
          console.log('WebSocket connected, doctor sending offer...');
          const offer = await peerConnectionRef.current!.createOffer();
          await peerConnectionRef.current!.setLocalDescription(offer);
          
          sendSignal({
            type: 'offer',
            sdp: offer.sdp || undefined,
            sender: user?.username,
          });
          
          isOfferSentRef.current = true;
          console.log('Offer sent via WebSocket');
        } catch (err) {
          console.error('Error sending offer:', err);
          setError('Failed to initiate call. Please try again.');
        }
      };

      sendOffer();
    }
  }, [wsConnectedState, isDoctor, user?.username, sendSignal]);

  // Initialize call on mount
  useEffect(() => {
    let mounted = true;

    const initCall = async () => {
      // Validate required data
      if (!appointmentId) {
        if (mounted) {
          setError('Invalid appointment ID.');
          setLoading(false);
        }
        return;
      }

      if (!user?.token) {
        if (mounted) {
          setError('You must be logged in to join the call.');
          setLoading(false);
        }
        return;
      }

      // Check if we have the required state
      if (!state || !doctorId || !patientId) {
        if (mounted) {
          setError('Missing appointment information. Please try starting the call again.');
          setLoading(false);
        }
        return;
      }

      // Start the call (initialize media and peer connection)
      await startCall();
    };

    initCall();

    // Cleanup on unmount
    return () => {
      mounted = false;
      endCall();
    };
  }, [appointmentId, user?.token]);

  // Layout component based on user role
  // If opened in popup, don't use layout wrapper (standalone mode)
  const otherPersonName = isDoctor ? patientName : doctorName;

  // Wrapper for popup mode (no layout)
  const PopupWrapper = ({ children }: { children: React.ReactNode }) => {
    if (isPopup) {
      return (
        <Box sx={{ minHeight: '100vh', bgcolor: 'background.default', p: 2 }}>
          <Box sx={{ maxWidth: 1200, mx: 'auto' }}>
            <Typography variant="h4" gutterBottom sx={{ mb: 2 }}>
              Video Call - {otherPersonName}
            </Typography>
            {children}
          </Box>
        </Box>
      );
    }
    return <>{children}</>;
  };

  // If popup mode, render without layout wrapper
  if (isPopup) {
    return (
      <PopupWrapper>
        <Box sx={{ maxWidth: 1200, mx: 'auto', p: 2 }}>
          {/* Error Display */}
          {error && (
            <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError(null)}>
              {error}
            </Alert>
          )}

          {/* Loading State */}
          {loading && (
            <Box display="flex" flexDirection="column" alignItems="center" justifyContent="center" minHeight="400px">
              <CircularProgress sx={{ mb: 2 }} />
              <Typography variant="body1">Initializing video call...</Typography>
            </Box>
          )}

          {/* Video Call Interface */}
          {!loading && (
            <Box>
              {/* Call Duration */}
              {isConnected && (
                <Box sx={{ textAlign: 'center', mb: 2 }}>
                  <Typography variant="h6" color="primary">
                    {formatDuration(callDuration)}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    {isConnected ? 'Connected' : 'Connecting...'}
                  </Typography>
                </Box>
              )}

              {/* Video Containers */}
              <Box sx={{ display: 'flex', gap: 2, mb: 2, flexDirection: { xs: 'column', md: 'row' } }}>
                {/* Remote Video (Other Person) */}
                <Card sx={{ flex: 1, minHeight: 400 }}>
                  <CardContent sx={{ p: 0, height: '100%' }}>
                    <Box
                      sx={{
                        width: '100%',
                        height: 400,
                        bgcolor: 'grey.900',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        position: 'relative',
                      }}
                    >
                      <video
                        ref={remoteVideoRef}
                        autoPlay
                        playsInline
                        style={{
                          width: '100%',
                          height: '100%',
                          objectFit: 'cover',
                        }}
                      />
                      {!isConnected && (
                        <Box
                          sx={{
                            position: 'absolute',
                            display: 'flex',
                            flexDirection: 'column',
                            alignItems: 'center',
                            gap: 2,
                          }}
                        >
                          <Person sx={{ fontSize: 60, color: 'grey.500' }} />
                          <Typography variant="body1" color="text.secondary">
                            {otherPersonName}
                          </Typography>
                          <Typography variant="body2" color="text.secondary">
                            Waiting for connection...
                          </Typography>
                        </Box>
                      )}
                    </Box>
                  </CardContent>
                </Card>

                {/* Local Video (You) */}
                <Card sx={{ width: { xs: '100%', md: 300 }, minHeight: 200 }}>
                  <CardContent sx={{ p: 0, height: '100%' }}>
                    <Box
                      sx={{
                        width: '100%',
                        height: 200,
                        bgcolor: 'grey.900',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        position: 'relative',
                      }}
                    >
                      <video
                        ref={localVideoRef}
                        autoPlay
                        playsInline
                        muted
                        style={{
                          width: '100%',
                          height: '100%',
                          objectFit: 'cover',
                        }}
                      />
                      {!isVideoEnabled && (
                        <Box
                          sx={{
                            position: 'absolute',
                            display: 'flex',
                            flexDirection: 'column',
                            alignItems: 'center',
                          }}
                        >
                          <VideocamOff sx={{ fontSize: 40, color: 'grey.500' }} />
                        </Box>
                      )}
                    </Box>
                  </CardContent>
                </Card>
              </Box>

              {/* Call Controls */}
              <Paper sx={{ p: 2, display: 'flex', justifyContent: 'center', gap: 2 }}>
                {/* Toggle Video */}
                <IconButton
                  color={isVideoEnabled ? 'primary' : 'error'}
                  onClick={toggleVideo}
                  size="large"
                >
                  {isVideoEnabled ? <Videocam /> : <VideocamOff />}
                </IconButton>

                {/* Toggle Audio */}
                <IconButton
                  color={isAudioEnabled ? 'primary' : 'error'}
                  onClick={toggleAudio}
                  size="large"
                >
                  {isAudioEnabled ? <Mic /> : <MicOff />}
                </IconButton>

                {/* End Call */}
                <IconButton
                  color="error"
                  onClick={handleEndCall}
                  size="large"
                  sx={{
                    bgcolor: 'error.main',
                    color: 'white',
                    '&:hover': {
                      bgcolor: 'error.dark',
                    },
                  }}
                >
                  <CallEnd />
                </IconButton>
              </Paper>

              {/* WebSocket Connection Status */}
              {!wsConnectedState && (
                <Alert severity="warning" sx={{ mt: 2 }}>
                  <Typography variant="body2">
                    Connecting to signaling server... {stompError && `(${stompError})`}
                  </Typography>
                </Alert>
              )}
            </Box>
          )}
        </Box>
      </PopupWrapper>
    );
  }

  // Normal mode with layout wrapper
  const Layout = isDoctor ? DoctorLayout : PatientLayout;

  return (
    <Layout title="Video Call" subtitle={`Appointment with ${otherPersonName}`}>
      <Box sx={{ maxWidth: 1200, mx: 'auto', p: 2 }}>
        {/* Error Display */}
        {error && (
          <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError(null)}>
            {error}
          </Alert>
        )}

        {/* Loading State */}
        {loading && (
          <Box display="flex" flexDirection="column" alignItems="center" justifyContent="center" minHeight="400px">
            <CircularProgress sx={{ mb: 2 }} />
            <Typography variant="body1">Initializing video call...</Typography>
          </Box>
        )}

        {/* Video Call Interface */}
        {!loading && (
          <Box>
            {/* Call Duration */}
            {isConnected && (
              <Box sx={{ textAlign: 'center', mb: 2 }}>
                <Typography variant="h6" color="primary">
                  {formatDuration(callDuration)}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  {isConnected ? 'Connected' : 'Connecting...'}
                </Typography>
              </Box>
            )}

            {/* Video Containers */}
            <Box sx={{ display: 'flex', gap: 2, mb: 2, flexDirection: { xs: 'column', md: 'row' } }}>
              {/* Remote Video (Other Person) */}
              <Card sx={{ flex: 1, minHeight: 400 }}>
                <CardContent sx={{ p: 0, height: '100%' }}>
                  <Box
                    sx={{
                      width: '100%',
                      height: 400,
                      bgcolor: 'grey.900',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      position: 'relative',
                    }}
                  >
                    <video
                      ref={remoteVideoRef}
                      autoPlay
                      playsInline
                      style={{
                        width: '100%',
                        height: '100%',
                        objectFit: 'cover',
                      }}
                    />
                    {!isConnected && (
                      <Box
                        sx={{
                          position: 'absolute',
                          display: 'flex',
                          flexDirection: 'column',
                          alignItems: 'center',
                          gap: 2,
                        }}
                      >
                        <Person sx={{ fontSize: 60, color: 'grey.500' }} />
                        <Typography variant="body1" color="text.secondary">
                          {otherPersonName}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                          Waiting for connection...
                        </Typography>
                      </Box>
                    )}
                  </Box>
                </CardContent>
              </Card>

              {/* Local Video (You) */}
              <Card sx={{ width: { xs: '100%', md: 300 }, minHeight: 200 }}>
                <CardContent sx={{ p: 0, height: '100%' }}>
                  <Box
                    sx={{
                      width: '100%',
                      height: 200,
                      bgcolor: 'grey.900',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      position: 'relative',
                    }}
                  >
                    <video
                      ref={localVideoRef}
                      autoPlay
                      playsInline
                      muted
                      style={{
                        width: '100%',
                        height: '100%',
                        objectFit: 'cover',
                      }}
                    />
                    {!isVideoEnabled && (
                      <Box
                        sx={{
                          position: 'absolute',
                          display: 'flex',
                          flexDirection: 'column',
                          alignItems: 'center',
                        }}
                      >
                        <VideocamOff sx={{ fontSize: 40, color: 'grey.500' }} />
                      </Box>
                    )}
                  </Box>
                </CardContent>
              </Card>
            </Box>

            {/* Call Controls */}
            <Paper sx={{ p: 2, display: 'flex', justifyContent: 'center', gap: 2 }}>
              {/* Toggle Video */}
              <IconButton
                color={isVideoEnabled ? 'primary' : 'error'}
                onClick={toggleVideo}
                size="large"
              >
                {isVideoEnabled ? <Videocam /> : <VideocamOff />}
              </IconButton>

              {/* Toggle Audio */}
              <IconButton
                color={isAudioEnabled ? 'primary' : 'error'}
                onClick={toggleAudio}
                size="large"
              >
                {isAudioEnabled ? <Mic /> : <MicOff />}
              </IconButton>

              {/* End Call */}
              <IconButton
                color="error"
                onClick={handleEndCall}
                size="large"
                sx={{
                  bgcolor: 'error.main',
                  color: 'white',
                  '&:hover': {
                    bgcolor: 'error.dark',
                  },
                }}
              >
                <CallEnd />
              </IconButton>
            </Paper>

            {/* WebSocket Connection Status */}
            {!wsConnectedState && (
              <Alert severity="warning" sx={{ mt: 2 }}>
                <Typography variant="body2">
                  Connecting to signaling server... {stompError && `(${stompError})`}
                </Typography>
              </Alert>
            )}
          </Box>
        )}
      </Box>
    </Layout>
  );
};

export default VideoCall;

