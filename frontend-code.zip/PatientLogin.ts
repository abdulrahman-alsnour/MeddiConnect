export interface LoginPatientRequestDTO {
  username: string;
  password: string;
} 