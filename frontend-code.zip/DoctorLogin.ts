export interface LoginHPRequestDTO {
  username: string;
  password: string;
} 